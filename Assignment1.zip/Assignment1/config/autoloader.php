
<?php
require 'Config.php';
 
    spl_autoload_register(function($class_name) {
        if(file_exists(FRAMEWORK_DIR."/" . $class_name . '.php')) {
            require FRAMEWORK_DIR."/" . $class_name . '.php';
        }
		elseif(file_exists(FRAMEWORK_DIR."/" . $class_name . 'Interface.php')) {
            require FRAMEWORK_DIR."/" . $class_name . 'Interface.php';
		}	
		elseif(file_exists(APP_DIR."/" . $class_name . '.php')) {
            require APP_DIR."/" . $class_name . '.php';
        }
		
		elseif(file_exists(CONTROLLERS_DIR."/" . $class_name . '.php')) {
            require CONTROLLERS_DIR."/" . $class_name . '.php';
        }
        elseif (file_exists(MODELS_DIR."/" . $class_name . '.php')) {
             require MODELS_DIR."/" . $class_name . '.php';
        }
		elseif (file_exists(VIEWS_DIR."/" . $class_name . '.php')) {
             require VIEWS_DIR."/" . $class_name . '.php';
        }
        elseif (file_exists(TPL_DIR."/" . $class_name . '.php')) {
           require TPL_DIR."/" . $class_name . '.php';
        }
        else {
            //error warning
            trigger_error('Cannot find class/abstract class: ' . $class_name, E_USER_WARNING);
            
            //Where the error occur
            debug_print_backtrace();
        }

    }); 
 
 