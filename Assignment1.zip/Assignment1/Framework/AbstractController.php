<?php

abstract class AbstractController
{
	
    //display model = database 
	protected $model = null;
	
	//display data on the view page 
 	protected $view = null;
	
	
	//set model for controller  
	public function setModel(Model $m) 
	{
		$this->model = $m;
	}
	
	
	// set the View object
	public function setView(View $v) 
	{

		$this->view = $v;
	}
	
	
	
	//call the methods within the controller
    //performs the page’s business logic 	
	abstract public function run();



}