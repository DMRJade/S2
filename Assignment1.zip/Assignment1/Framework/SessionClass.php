<?php

class SessionClass
{

    private $allowedPages = [
        'profile',
        'courses'
        // Add more pages as needed
    ];

	public static function create()
	{
		session_start();
	}
	
	
	public function add($name, $value)
	{
		//validate name 
		$this->$_SESSION[$name] = $value;
	}
	
	
     //check user name and if login in 
    public static function isLoggedIn($name)
    {
        if(isset($_SESSION[$name]))
		{
		   return ($_SESSION[$name]);
		}
		Return null;
    }


    public function accessible($user, $page): bool
    {
		 // Check if the user is logged in
		if (!$this->isLoggedIn($user))
		{
				return false;

		}
	
		// Check if the page is in the list of allowed pages
		if (in_array($page, $this->allowedPages)) 
		{
				return true;
		}
	
			return false;


    }
	
	
	//accessible($user, $page): bool

    /*
	Public function accessible($user, $page): bool
	{
		 if ($user === null || $page === null)
		 {
			return false; // User is not logged in
		 }
		 
	  
		  if ($page === 'profile' || $page === 'courses') 
		  {
			  if ($this->isLoggedIn($user))
				  return true;
			  else 
				  return false;
			  
		  }
		return false;
     		
		
    }
    
   
*/
		
	
	
	public function remove($name) 
	{
		if (isset($_SESSION[$name])) 
		{
			unset($_SESSION[$name]);
			return true;
		} 
		else 
		{
			return false; // Variable doesn't exist in session
		}
	}
	
	//use to logout 
    public static function destroy()
    {
      // Unset all of the session variables
      $_SESSION = [];

      // Delete the session cookie
      if (ini_get('session.use_cookies')) {
          $params = session_get_cookie_params();

          setcookie(
              session_name(),
              '',
              time() - 42000,
              $params['path'],
              $params['domain'],
              $params['secure'],
              $params['httponly']
          );
      }

      // Finally destroy the session
      session_destroy();
    }

}

