<?php

require 'Config/autoloader.php';


$controller = new IndexController();
$controller->run();