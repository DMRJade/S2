<?php
class IndexModel extends Model
{

    private $Data = [];

    public function getAll() : array
    {
        
        $PopularArr = [];
        $RecomArr= [];
        
        $popQuery = "SELECT courses.course_image,courses.course_name, instructors.instructor_name, courses.course_access_count
					FROM courses
					JOIN instructors ON courses.course_id=instructors.instructor_id
					ORDER BY course_access_count DESC LIMIT 8";

        $recQuery  = "SELECT courses.course_image,courses.course_name, instructors.instructor_name, courses.course_recommendation_count
					  FROM courses
					  JOIN instructors ON courses.course_id=instructors.instructor_id
					  ORDER BY course_recommendation_count DESC LIMIT 8";

        
       $popResult = $this->db->query($popQuery);
       $recResult = $this->db->query($recQuery);
        
       while ($row = $popResult->fetch_assoc()) 
       {
            $PopularArr[] = $row;
        }
        
        
        while ($row = $recResult->fetch_assoc()) 
        {
            $RecomArr[] = $row;

        }
       
        $this->db->close();
			
        $this->Data = array(
            'Popular' => $PopularArr,
            'Recommended' => $RecomArr
        );
        
     
        foreach ($this->observers as $observer) {
            $this->notify($observer);
            
        }

         return $this->Data;
    }



    public function getData()
    {
        return $this->Data;
    }


    public function getRecord(string $id) : array
    {

        return [];
    }




   





}

