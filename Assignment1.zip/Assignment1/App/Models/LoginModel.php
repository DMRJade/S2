<?php
class LoginModel extends Model
{

    private $data;
  
    public function login(array $userData)
    {
        $email = $userData['email'];
        $password = $userData['password'];
       
            // Retrieve the hashed password from the database for the given username
            $query = "SELECT * FROM users WHERE email = ?";
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
           
    
            if ($result->num_rows > 0) 
            {
                $user = $result->fetch_assoc();
               
                $hashedPassword = $user['password'];
                // Verify password against hashed password
                if (password_verify($password, $hashedPassword)) 
                {
                  
                    $this->data['message'] = "User login was successfully.";
                    $this->data['LoginStatus'] = true;
                    $this->data['LoginUser'] = $user['email']; 

                   
                } 
                else 
                {
                    $this->data['message'] = "Invalid username or password";
                    $this->data['LoginStatus'] = false;
                    $this->data['LoginUser'] = 0;


                
                }
            } 
            else 
            {
                $this->data['message'] = "Invalid username or password";
                $this->data['LoginStatus'] = false;
                $this->data['LoginUser'] = 0;
               
            }
            
            
            foreach ($this->observers as $observer) {
                $this->notify($observer);
                
            }

           // print_r($this->data);

            return $this->data;

        }


       public function getAll(): array
		{
			
			return [];
		}

   
    public function getRecord(string $id) : array
    {
		
       return [];
    }

  
    public function getData()
    {
        
       
        return $this->data;
    }


  


}


