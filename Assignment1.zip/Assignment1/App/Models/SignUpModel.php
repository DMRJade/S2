<?php
class SignUpModel extends Model
{
    private $data = [];

    public function emailExist($email)
    {
        // Check if user already exists
        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            return true; // User exists
        }
        return false; // User does not exist
    }

    public function addUser(array $userData): bool
    {
        $email = $userData['email'];
        $password = $userData['password'];
        $name = $userData['FullName'];

        if ($this->emailExist($email)) {
            $this->data['message'] = 'Email already exists';
            $this->data['SignupStatus'] = false;
            return false;
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $query = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("sss", $name, $email, $hashedPassword);
        $insert = $stmt->execute();

        if (!$insert) {
            $this->data['message'] = 'Error occurred. User was not inserted';
            $this->data['SignupStatus'] = false;
            return false;
        }

        $this->data['message'] = 'Sign Up Successful. Please login below';
        $this->data['SignupStatus'] = true;
        return true;
    }

    public function getData()
    {
        return $this->data;
    }

    public function getAll(): array
    {
        // Implement this method to retrieve all records from the database
        return [];
    }

    public function getRecord(string $id): array
    {
        // Implement this method to retrieve a specific record from the database
        return [];
    }


}