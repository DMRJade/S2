<?php


class SignUpView extends View
{

    
   



    public function update(Observable $observable)
    {
        $data = $observable->getData();

        //isset($_POST['email']

        print_r($data);

        if (!empty($data)) 
        {
           $data['message'] = 'Sign Up Successful. Please login below';


            if ($data['SignupStatus'] == true)
            {
                $this->setTemplate( TPL_DIR . '/login.tlp.php');
                $this->addVar('success', $data['message'] );
           
            }

            if ($data['SignupStatus'] == false)
            {
                $this->addVar('error', $data['message'] );
           
            }

        }
    }

     
 








}