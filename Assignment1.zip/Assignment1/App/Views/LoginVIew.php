<?php


class LoginVIew extends View
{
    public function update(Observable $observable)
    {
        $data = $observable->getData();



          // Start session and set user as logged in
          //session_start();
          //$_SESSION['username'] = $email;

        print_r($data);
        exit;

        print_r($data['SignupStatus']);
        print_r($data['message']);
        exit;

        if (!empty($data)) 
        {
           


            if ($data['SignupStatus'] == true)
            {
               print_r($data['It work']);
            }

            if ($data['SignupStatus'] == false)
            {
                $this->addVar('error', $data['message'] );
           
            }

        }

    
    }












}