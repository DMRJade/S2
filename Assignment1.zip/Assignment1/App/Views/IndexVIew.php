<?php


class IndexView extends View
{

    public function update(Observable $observable)
    {
        $data = $observable->getData(); 

        $popular = $data['Popular'];
        $recommend = $data['Recommended'];

       // $indexData['pop1'] = array_slice($popular, 0, 4);
        //$indexData['pop2']= array_slice($popular, 4, 4);
        //$indexData['$rec1'] = array_slice($recommend, 0, 4);
        //$indexData['rec2'] = array_slice($recommend, 4, 4);

     

        foreach ($data as $key => $value) 
        {
                   
            $this->addVar($key, $value);
           // print_r($key);
            //exit;
        }
        $this->display();

    }












}