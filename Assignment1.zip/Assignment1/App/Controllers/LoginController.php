<?php



class LoginController extends AbstractController
{
   
  

    public function run()
    {
       $this->setModel(new LoginModel);
        $this->setView(new LoginView);
        
        $this->view->setTemplate(TPL_DIR . '/Login.tlp.php');

         if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            $valid = new Validator();
            if (!$valid->isloginValid($_POST))
            {
                $err = $valid->getErrorMessages();

              
                
                $this->view->addVar('errors', $err);
				$this->view->display();
                exit;
				
			}

             $this->model->login($_POST);
             $this->model->attach($this->view);
                
               
                //$this->model->getRecord();

			
		 
		}
        else
        {
            $this->view->display();

        }
		  
			
        

	}	
			

			
			
			
 }

  




 


