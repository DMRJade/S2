<?php
class SignUpController extends AbstractController
{
    public function run()
    {
        $this->setModel(new SignUpModel);
        $this->setView(new SignUpView);

        $this->view->setTemplate(TPL_DIR . '/SignUp.tlp.php');

        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
           
            $valid = new Validator();

            if (!$valid->isSignUpValid($_POST))
            {
                $err = $valid->getErrorMessages();
               
                
                $this->view->addVar('errors', $err);
				$this->view->display();
                exit;
            }

            $this->model->addUser($_POST);
            $this->model->attach($this->view);
            $this->model->notify($this->view);
            
            // Uncomment the following line if you want to display the view after notifying the model
             //$this->view->display();
        }
        
        else 
        {
            $this->view->display();
        }
    }
}
