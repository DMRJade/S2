<?php

class IndexController extends AbstractController
{
    


    
    public function run()
    {
        
        
        $this->setModel(new IndexModel);
        $this->setView( new IndexView);

        $this->view->setTemplate(TPL_DIR . '/index.tlp.php');


        $this->model->attach($this->view);
        $this->model->getAll();
       
        //$this->view->display();
        

       // $this->model->notify();
    }




  

}