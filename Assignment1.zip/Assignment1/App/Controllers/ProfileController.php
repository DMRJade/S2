<?php

class ProfileController extends AbstractController
{
    
    

    
    public function run()
    {
         $session = new SessionClass();
    
        
        //$this->setModel(new ProfileModel);
        $this->setView( new ProfileView);

        $this->view->setTemplate(TPL_DIR . '/Profile.tlp.php');

        $user = $session->isLoggedIn('user');

        if (!$session->accessible($user, 'profile')) 
        {
            
            
            $this->view->setTemplate(TPL_DIR . '/Login.tlp.php');
            $this->view->display();
            exit;


            

        }

        $this->view->display();
        

    }




  

}