<?php

class CoursesController extends AbstractController
{
    


    
    public function run()
    {
        $session = new SessionClass();
        
        $this->setModel(new CoursesModel);
        $this->setView( new CoursesView);

        $this->view->setTemplate(TPL_DIR . '/Courses.tlp.php');


        $user = $session->isLoggedIn('user');

        if (!$session->accessible($user, 'course')) 
        {
            
            
            $this->view->setTemplate(TPL_DIR . '/Login.tlp.php');
            $this->view->display();
            exit;


            

        }

      
        $this->model->attach($this->view);
        $this->model->getAll();
       
        //$this->view->display();
        

       // $this->model->notify();








    }




  

}