<?php

require '../../02608001/config/autoloader.php';
//use Framework\FrontController;


//use Framework\Controller\FrontController;
//new FrontController();


//$_SERVER['QUERY_STRING']


//echo "<pre>";
   //var_dump($_SERVER['QUERY_STRING']);
 
   // echo "</pre>";
   //var_dump($_REQUEST);
   

  // var_dump("index");

//$frontController = new Framework\FrontController();
//$frontController = new FrontController();
//$frontController->handleRequest();


$requestHandler = Framework\RequestHandler::getInstance();
//$requestHandler = RequestHandler::getInstance();
$requestHandler->handleRequest();