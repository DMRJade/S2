
<?php
require 'Config.php';
 
//namespace
 spl_autoload_register(function ($class) {
    // Define the root directory of your project
    $root = 'C:/xampp/02608001/';

    // Replace backslashes with directory separators in the class name
    $class = str_replace('\\', DIRECTORY_SEPARATOR, $class);

    // Concatenate the root directory with the class name
    $file = $root . $class . '.php';
   
//echo "<pre>";
//var_dump($file);
 //   echo "</pre>";
  

    // Check if the file exists and require it
    if (file_exists($file)) {
        require $file;
    }
});
