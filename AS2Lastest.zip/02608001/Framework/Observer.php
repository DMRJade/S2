<?php
namespace Framework;

use Framework\Observable;



interface Observer
{

   public function update(Observable $observable);



}