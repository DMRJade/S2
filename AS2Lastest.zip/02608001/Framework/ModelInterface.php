<?php
namespace Framework;

use Framework\Observable;

interface ModelInterface
{

   public function makeConnection();
   public function findAll();
   public function findRecord($id);
   public function createObject(array $record) : DomainObject;
    public function doCreateObject(array $record) : DomainObject;






}