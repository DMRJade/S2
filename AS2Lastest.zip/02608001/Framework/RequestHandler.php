<?php
namespace Framework;

use App\Commands\CommandFactory;

use Framework\CommandContext;

  // var_dump("rh");

class RequestHandler
{
    private static $instance;
    private $context;

    private $Pages = 
    [
        'profile',
        'courses',
        'Courses',
        'login',
        'signup', 
        'logout' 
        
    ];


    // Private constructor to prevent instantiation from outside
    private function __construct()
    {
        $this->context = new CommandContext();
		
    }

    // Method to get the singleton instance
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getContext(): CommandContext
    {
        return $this->context;
    }

    public function handleRequest()
    {
        $action = $this->context->get('action');

        //var_dump($action);
        //$action = (isset($action) && !empty($action)) ? $action : "index";
        $action = in_array(strtolower($action), $this->Pages)? $action : "index";

        //var_dump($action);

        $cmd = CommandFactory::getCommand($action);

      
        $cmd->run();

        /*if (!$cmd->run($this->context))
		{
            var_dump( "fail  rh");
			// handle failure
			 //$this->handleError(); // Assuming handleError() method is defined
        }
		else 
		{
			var_dump("works");
            // success - dispatch view or do nothing
        }
        */
    }


   








}


