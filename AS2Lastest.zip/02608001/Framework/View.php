<?php
namespace Framework;

class View implements Observer 
	{
		
	  private $vars = [];
	  private $tpl = '';



        public function setTemplate( $filename)
        {
            $file = TPL_DIR."\\$filename"; 
            

                if (!file_exists($file))
                {
                    trigger_error('Error: File ' . $file . ' does not exist.', E_USER_ERROR);
                }
                
                if (empty($file))
                {
                    trigger_error('Error: Please enter a filename', E_USER_ERROR);
                }
                
                $this->tpl = $file;
        }


        
        public function addVar( $name, $value)
        {
                $this->vars[$name] = $value;
               // print_r($this->vars);
                //exit;
        }


   //pass mutliple varibles 
       public function addVars(array $variables)
        {
                if (empty($variables))
                {
                    trigger_error('View Error: Variable Array is Empty', E_USER_ERROR);
                }
                foreach ($variables as $name=>$value)
                {
                    $this->vars[$name] = $value;
                }
                
              

        }


        //show view file 
        public function display()
        {
            extract($this->vars);

            require $this->tpl;

        }


        
    // Method to implement Observer pattern
    public function update(Observable $observable) 
    {
        
        
        //$this->display();
    }





}

