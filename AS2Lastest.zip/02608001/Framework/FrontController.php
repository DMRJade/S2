<?php
namespace Framework;

use Framework\RequestHandler;

var_dump("FrontController");

class FrontController
{
    private $requestHandler;

    public function __construct()
    {
        $this->requestHandler = RequestHandler::getInstance();

    }

    public function handleRequest()
    {


                //$this->requestHandler->handleRequest();
		$this->requestHandler->handleRequest();

    }
}