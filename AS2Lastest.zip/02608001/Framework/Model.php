<?php

namespace Framework;

use Framework\Observable;
use Framework\Observer;
use Framework\ModelInterface;
use Framework\DomainObject;
use PDOStatement;


abstract class Model implements Observable, ModelInterface
{
   
    protected $observers = [];

    protected $data;
  
    protected \PDO $pdo;

    public function __construct()
    {
		$this->makeConnection();
        
       
    }
	
	    public function makeConnection()
    {
        try 
        {
           $this->pdo = new \PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASSWORD);
 
           // set the PDO error mode to exception
           $this-> pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
          // echo "Connected successfully";
         } 
         
         catch(\PDOException $e) 
         {
           echo "Connection failed: " . $e->getMessage();
         }
        
        
    }
     
  
    public function attach(Observer $observer) 
    {
        $this->observers[] = $observer;
    }

    public function detached(Observer $observer) 
    {
        $key = array_search($observer,$this->observers, true);
        if(false !== $key) 
        {
            unset($this->observers[$key]);
        }
    }

    public function notify()
    {
        foreach ($this->observers as $observer) {
            $observer->update($this);
        }
    }


	 public function getData()
    {
        return $this->data;
    }
	

    public function createObject(array $record): DomainObject
    {
        return $this->doCreateObject($record);
    }
	


    public function getstatement(string $qrystatement): PDOStatement
    {
               
        $statement = $qrystatement . 'Stmt';
        return $this->$statement;
       
    }    




    public function findRecord(mixed $id): DomainObject|null
    {
        $this->getstatement('select')->execute([$id]);
        $record = $this->getstatement('select')->fetch();
        $this->getstatement('select')->closeCursor();
        if (!is_array($record)) {
            return null;
        }
        return $this->createObject($record);
    }


    abstract public function findAll(): mixed;
    abstract public function doCreateObject(array $record): DomainObject;






}