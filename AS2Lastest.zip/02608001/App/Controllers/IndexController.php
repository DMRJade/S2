<?php
namespace App\Controllers;

use App\Models\IndexModel;
use App\Views\IndexView;
use Framework\Controller;

//var_dump("IC");

class IndexController extends Controller
{
    
	
    
    public function run()
    {
        
        $this->setModel(new IndexModel);
        $this->setView(new IndexView);

        $this->view->setTemplate('index.tlp.php');


        $this->model->attach($this->view);
        $this->model->findAll();
       

        //old
        //$this->view->display();
        

       // $this->model->notify();
	   //return true;
    }









  

}