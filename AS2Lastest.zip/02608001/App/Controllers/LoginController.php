<?php

namespace App\Controllers;

use App\Models\LoginModel;
use App\Views\LoginView;
use Framework\Controller;
use Framework\Validator;
use Framework\SessionClass;


class LoginController extends Controller
{
   
  

    public function run()
    {
       $this->setModel(new LoginModel);
        $this->setView(new LoginView);
        $session = SessionClass::getInstance();
        
        $this->view->setTemplate('Login.tlp.php');
       

         if ($_SERVER["REQUEST_METHOD"] === "POST") 
        {

            $valid = Validator::getInstance();
         
            
            if (!$valid->isloginValid($_POST))
            {
                $err = $valid->getErrorMessages();
         
                
                $this->view->addVar('errors', $err);
                $this->view->addVar('user',$session->get('user'));
				$this->view->display();
                exit;
				
			}
            else{
                $this->model->attach($this->view);
                $this->model->login($_POST);


            }

               
              
                
        
		}
        else
        {
			$session = SessionClass::getInstance();
			$this->view->addVar('user',$session->get('user'));

            $this->view->display();

        }
		  
			
        

	}	
			

			
			
			
 }

  




 


