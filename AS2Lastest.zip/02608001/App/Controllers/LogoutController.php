<?php

namespace App\Controllers;

use Framework\SessionClass;

use Framework\Controller;


class LogoutController extends Controller
{
   
    public function run()
    {
		
        $session = SessionClass::getInstance();

        $session->destroy();
		//$session->remove('user');
      
		var_dump(SessionClass::getInstance()->get('user'));
		header('Location:index.php?action=login');

        
	}	
			

			
			
			
 }

  




 


