<?php
namespace App\Views;

use Framework\Observable;
use Framework\View;
use Framework\SessionClass;


class CoursesView extends View
{

    public function update(Observable $observable)
    {
        $data = $observable->getData(); 
		//$session = SessionClass::getInstance();

                
        foreach ($data as $key => $value) 
        {
                   
            $this->addVar($key, $value);
			
        
        }
		//$this->addVar('user',$session->get('user'));
        $this->display();

    }












}