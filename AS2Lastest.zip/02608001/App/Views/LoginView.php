<?php
namespace App\Views;

use Framework\Observable;
use Framework\View;
use Framework\SessionClass;



class LoginVIew extends View
{
    public function update(Observable $observable)
    {
        $data = $observable->getData();
		$session = SessionClass::getInstance();
       	
        if (!empty($data)) 
        {
			   
            if ($data['LoginStatus'] == true)
            {
			   
			  	
			  		   
			   $this->setTemplate('Profile.tlp.php');
			   $this->display();
			   		//header('Location:index.php?action=profile');

			  
            }
            else if ($data['LoginStatus'] === false)
            {
               
				
			     $this->addVar('success', $data['errorMessage'] );
				 $this->addVar('user',$session->get('user'));
				 $this->setTemplate('Login.tlp.php');
				 $this->display();
           
            }

        }
		

    
    }









}