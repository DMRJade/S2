<?php
namespace App\Views;

use Framework\Observable;
use Framework\View;

class ProfileView extends View
{

    public function update(Observable $observable)
    {
       

    }












}