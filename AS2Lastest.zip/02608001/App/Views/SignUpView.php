<?php
namespace App\Views;

use Framework\Observable;
use Framework\View;
use Framework\SessionClass;


class SignUpView extends View
{

    public function update(Observable $observable)
    {
        $data = $observable->getData();
		foreach ($data as $key => $value) {
            $this->addVar($key, $value);
        }

        //var_dump("session" );
		//var_dump(SessionClass::getInstance()->get('user'));
		 
		 if (!empty($data)) 
		 {
			 
			if ($data['SignupStatus'] === true)
            {
				//var_dump($data['message'] );
                $this->setTemplate( 'login.tlp.php');
                $this->addVar('success', $data['successMessage'] );
				$this->addVar('user',$session->get('user'));
				$this->display();
           
            }
			
			elseif ($data['SignupStatus'] === false)
            {
				
                //var_dump("SignupStatus error");
				//var_dump($data['message']);
				
                $this->setTemplate( 'signup.tlp.php');
				$this->addVar('SignupMessage', $data['errorMessage'] );
				$this->addVar('user',$session->get('user'));
				$this->display();
		    }
			 
		 }
		 
		 

    }

     
 








}