<?php
namespace App\Models;

use Framework\Model;
use App\DomainObjects\IndexDomainObject;
use Framework\DomainObject;

//var_dump("IM");

class IndexModel extends Model
{

    protected \PDOStatement $topRecommendedStmt;
    protected \PDOStatement $mostPopularStmt;
	
	public function __construct()
	{
		parent::__construct();
	
		$this->topRecommendedStmt = $this->pdo->prepare(
								 "SELECT 
								 courses.course_image,courses.course_name, instructors.instructor_name
								 FROM courses
								 JOIN instructors ON courses.course_id=instructors.instructor_id
								 ORDER BY course_recommendation_count DESC LIMIT 8"
								 );
								 
		$this->mostPopularStmt = $this->pdo->prepare(
								"SELECT courses.course_image,courses.course_name, instructors.instructor_name
								FROM courses
								JOIN instructors ON courses.course_id=instructors.instructor_id
								ORDER BY course_access_count DESC LIMIT 8"
								);
	}
	
	
	
	
	public function doCreateObject(array $record): DomainObject
     {
        return new IndexDomainObject(
            $record['course_image'],
			$record['course_name'],
            $record['instructor_name'],
        );
     }

	
	
		
	public function findAll(): bool
	{
		// Execute top recommended query
		if(!$this->executeQuery('topRecommended', 'topRecommended')) {
			return false;
		}

		// Execute most popular query
		if (!$this->executeQuery('mostPopular', 'mostPopular')) {
			return false;
		}


		// Notify observers
		$this->notify();

		return true;
	}
	
	

		private function executeQuery($statement, $key): bool 
		{
			$stmt = $this->getstatement($statement);
			if (!$stmt) {
				return false;
			}
			
			if (!$stmt->execute()) {
				return false;
			}

			while ($record = $stmt->fetch()) {
				$this->data[$key][] = $this->createObject($record);
			}
			$stmt->closeCursor();
			
			return true;
		}

			



}

