<?php

namespace App\DomainObjects;

use Framework\DomainObject;

class LoginDomainObject extends DomainObject {
    public $email = '';
    public $password = '';

    public function __construct($email, $password)
    {
        $this->email = $email;
        $this->password = $password;
    }
}