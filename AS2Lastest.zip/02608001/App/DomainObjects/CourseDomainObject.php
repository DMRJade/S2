<?php

namespace App\DomainObjects;

use Framework\DomainObject;

class CourseDomainObject extends DomainObject {
   
    public $course_image = '';
    public $faculty_dept_name = ''; 
    public $course_name = '';
   
    public $instructor_name = '';
    
    
    public function __construct( $course_image, $faculty_dept_name,$course_name,$instructor_name, )
    {
        $this->course_image = $course_image;
        $this->faculty_dept_name = $faculty_dept_name;
        $this->course_name = $course_name;
        $this->instructor_name = $instructor_name;
        
    }
}

