
<?php
 //DATABASE INFO
 const DB_USER = 'root';   
 const DB_NAME = 'quwius';
 const DB_HOST = 'localhost';
 const DB_PASSWORD = '';



//DIRECTORIES

define('ROOT_DIR', 'C:\xampp\02608001');
define('APP_DIR', ROOT_DIR . '\app');
define('FRAMEWORK_DIR', ROOT_DIR . '\Framework');
define('TPL_DIR', ROOT_DIR . '\tpl');
define('CONFIG_DIR', ROOT_DIR . '\config');



//APP Subfolder
define('VIEWS_DIR', APP_DIR . '\Views');
define('CONTROLLERS_DIR', APP_DIR . '\Controllers');
define('MODELS_DIR', APP_DIR . '\Models');
define('COMMANDS_DIR', APP_DIR . '\Commands');


 
 
 
 
 




