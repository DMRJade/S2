<?php

namespace App\DomainObjects;

use Framework\DomainObject;

class IndexDomainObject extends DomainObject {
    
    
    public $course_image = '';
    public $course_name = '';
    public $instructor_name = '';

    public function __construct($course_image, $course_name, $instructor_name)
    {  
        $this->course_image = $course_image;
        $this->course_name = $course_name;
        $this->instructor_name = $instructor_name;
    }
}