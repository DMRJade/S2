<?php
namespace App\Controllers;

use App\Models\SignUpModel;
use App\Views\SignUpView;
use Framework\Controller;
use Framework\Validator;
use Framework\SessionClass;



class SignUpController extends Controller
{
    public function run()
    {
        $this->setModel(new SignUpModel);
        $this->setView(new SignUpView);

        $this->view->setTemplate('SignUp.tlp.php');

        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
           
            $valid = Validator::getInstance();

            if (!$valid->isSignUpValid($_POST))
            {
                $err = $valid->getErrorMessages();
               
                
                $this->view->addVar('errors', $err);
				$this->view->display();
                exit;
            }

            $this->model->attach($this->view);
            $this->model->addUser($_POST);
            //$this->model->notify($this->view);
            
            // Uncomment the following line if you want to display the view after notifying the model
             //$this->view->display();
        }
        
        else 
        {
			$session = SessionClass::getInstance();
			$this->view->addVar('user',$session->get('user'));
            $this->view->display();
        }
    }
}
