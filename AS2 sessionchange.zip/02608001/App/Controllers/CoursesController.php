<?php

namespace App\Controllers;

use App\Models\CoursesModel;
use App\Views\CoursesView;
use Framework\Controller;
use Framework\SessionClass;


//var_dump("CC");


class CoursesController extends Controller
{
    


    
    public function run()
    {
        


		$session = SessionClass::getInstance();
        
        $this->setModel(new CoursesModel);
        $this->setView(new CoursesView);

        $this->view->setTemplate('Courses.tlp.php');


       
        if (!$session->accessible('user', 'courses')) 
        {
            
            
            $this->view->setTemplate('Login.tlp.php');
			$this->view->addVar('user',$session->get('user'));
           $this->view->display();
            exit;
           //header('Location: index.php?action=login');
            //exit;

        }

      
        $this->model->attach($this->view);
        $this->model->findAll();
       
        //$this->view->display();
   
       // $this->model->notify();

    }




  

}