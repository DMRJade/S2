<?php
namespace App\Views;

use Framework\Observable;
use Framework\View;
use Framework\SessionClass;

//var_dump("IV");

class IndexView extends View
{

    public function update(Observable $observable)
    {
        $data = $observable->getData(); 
		$session = SessionClass::getInstance();
		
		//var_dump("session" );
		//var_dump($session->get('user'));

        foreach ($data as $key => $value) 
        {
                    
            $this->addVar($key, $value);
			$this->addVar('user',$session->get('user'));
           
   
        }
        $this->display();

    }


}