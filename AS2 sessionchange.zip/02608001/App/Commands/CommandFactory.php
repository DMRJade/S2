<?php

namespace App\Commands;

use Framework\Controller;

class CommandFactory 
{
    public static function getCommand(string $action): Controller
    {
        $commandname = 'App\\Controllers\\' . ucfirst($action) . 'Controller';
        $command = new $commandname();
        return $command;
    }
}

