<?php
namespace Framework;

class SessionClass
{
    private $allowedPages = [
        'profile',
        'courses'
        // Add more pages as needed
    ];

    private static $instance;

    private function __construct() {}

    public static function getInstance() {
        if (empty(self::$instance)) {
            self::$instance = new SessionClass();
        }
        return self::$instance;
    }

    public function create() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function add($name, $value) {
        $this->create();
        $_SESSION[$name] = $value;
    }

    public function get($name) {
        $this->create();
        return isset($_SESSION[$name]) ? $_SESSION[$name] : null;
    }

    public function isLoggedIn($name): bool {
        $this->create();
        return isset($_SESSION[$name]);
    }

    public function accessible($user, $page): bool {
        $this->create();
        // Check if the user is logged in
        if (!$this->isLoggedIn($user)) {
            return false;
        }
        // Check if the page is in the list of allowed pages
        return in_array($page, $this->allowedPages);
    }

    public function remove($name) {
        $this->create();
        if (isset($_SESSION[$name])) {
            unset($_SESSION[$name]);
            return true;
        } else {
            return false; // Variable doesn't exist in session
        }
    }

    public function destroy() {
        if (session_status() === PHP_SESSION_ACTIVE) {
            // Destroy the session
            session_destroy();
        }
    }
}
