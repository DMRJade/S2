<?php
namespace Framework;

use Framework\Observer;


interface Observable
{

    public function attach(Observer $observer);
    public function detached(Observer $observer);

    public function notify();    



}