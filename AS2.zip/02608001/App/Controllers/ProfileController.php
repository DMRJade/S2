<?php
namespace App\Controllers;

use App\Models\ProfileModel;
use App\Views\ProfileView;
use Framework\Controller;
use Framework\SessionClass;



class ProfileController extends Controller
{
    
    
    public function run()
    {
		
		// Initialize session
		$session = SessionClass::getInstance();

		// Initialize the view
		$this->setView(new ProfileView);
		
		$this->view->setTemplate('Profile.tlp.php');
		$this->view->addVar('user',$session->get('user'));
		
		//var_dump($session->accessible('user', 'profile'));
		//var_dump($session->get('user'));
		//exit;

		// Check if the user has access to the profile page
		if (!$session->accessible('user', 'profile')) 
		{
			// If the user doesn't have access, redirect to the login page
			$this->view->setTemplate('Login.tlp.php');
			//$this->addVar('user',$session->get('user'));
			$this->view->display();
			exit;

			//header('Location: index.php?action=login');
           // exit;
		}

        
          
		// Display the view
		$this->view->display();

	}




  

}