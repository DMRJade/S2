<?php
namespace App\Models;

use Framework\Model;
use App\DomainObjects\LoginDomainObject;
use Framework\DomainObject;
use Framework\SessionClass;

class LoginModel extends Model
{

      
    protected \PDOStatement $selectStmt;
  
    
	
	public function __construct()
	{
		parent::__construct();
	
        $this->selectStmt = $this->pdo->prepare(
            "SELECT * FROM users WHERE email =?"
           );


	}



  
    public function login(array $userData)
    {
		
        $this->data['email'] = $userData['email'];
        $this->data['password'] = $userData['password'];
		//var_dump($userData['email']);
    
        $user = $this->findRecord($this->data['email']);
    
          
        if ($user && password_verify($this->data['password'], $user->password)) 
        {
           $_SESSION['user'] = $user->email;
	      /***********             	
	         I used 
         	// Storing user object in the session
	        //$session = SessionClass::getInstance();
           var_dump("Fer user" . $user->email);
		   var_dump($session->get('user'));
		   var_dump($_SESSION);
           
		 ****************/
  

            $this->data['LoginStatus'] = true;
            $this->data['successMessage'] = "User login was successful.";
        } 
        else 
        {
            $this->data['LoginStatus'] = false;
            $this->data['errorMessage'] = "Invalid username or password";
            // Unsetting password for security 
            unset($this->data['password']);
        }
    
        // Notify observers
        $this->notify();
    }
    


        public function doCreateObject(array $record): DomainObject
        {
            return new LoginDomainObject(
                 $record['email'],
                 $record['password']
                
            );
        }





       public function findAll(): array
		{
			
			return [];
		}

   
    
  
  

  


}


