<?php
namespace App\Models;

use Framework\Model;
use App\DomainObjects\UserDomainObject;
use Framework\DomainObject;


class SignUpModel extends Model
{


    protected \PDOStatement $selectStmt;
    protected \PDOStatement $insertStmt;
    
	
	public function __construct()
	{
		parent::__construct();
	
		$this->selectStmt = $this->pdo->prepare(
                                             "SELECT * FROM users WHERE email =?"
								            );


        $this->insertStmt = $this->pdo->prepare(
                                                'INSERT INTO users (name, email, password) VALUES(?,?,?)'
                                            );
								 
	
	}


    public function addUser(array $userData) :bool
    {
        $this->data['email'] = $userData['email'];
        $this->data['password'] = $userData['password'];
        $this->data['FullName']= $userData['FullName'];

        $result = $this->findRecord($this->data['email']) === null;
        if(!$result) 
        {
            unset($this->data['password']);
            $this->data['errorMessage'] = 'Email already exists';
            $this->data['SignupStatus'] = false;

        }
        else
         {
            unset($this->data['password']);
            $this->data['successMessage'] = 'Sign Up Successful. Please login below';
            $this->data['SignupStatus'] = true;
        }

        $this->notify();

        return $result;
    }


    public function insertUser(UserDomainObject $user) 
    {
        $values = [$user->name,$user->email,password_hash($user->password,PASSWORD_DEFAULT)];
        $this->getstatement('insert')->execute($values);
        $this->getstatement('insert')->closeCursor();
    } 

    public function findAll(): array
    {
        // Implement this method to retrieve all records from the database
        return [];
    }


    public function doCreateObject(array $record): DomainObject
    {
        return new UserDomainObject(
            $record['name'],
            $record['email'],
            $record['password']
        );
    } 











}