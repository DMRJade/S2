<?php
namespace App\Models;

use Framework\Model;
use App\DomainObjects\CourseDomainObject;
use Framework\DomainObject;


//var_dump("CM");

class CoursesModel extends Model
{
    protected \PDOStatement $coursesStmt;
    
	
	public function __construct()
	{
		parent::__construct();
	
		$this->coursesStmt = $this->pdo->prepare(
                                    "SELECT
                                    courses.course_image,faculty_department.faculty_dept_name, courses.course_name, instructors.instructor_name
                                    FROM courses
                                    JOIN instructors ON courses.course_id=instructors.instructor_id
                                    JOIN faculty_dept_courses ON courses.course_id = faculty_dept_courses.course_id
                                    JOIN faculty_department ON faculty_department.faculty_dept_id = faculty_dept_courses.faculty_dept_id
                                    ORDER BY faculty_department.faculty_dept_name ASC, courses.course_name ASC"
								 );
								 
	
	}
 
   
		public function doCreateObject(array $record): DomainObject
		{
			return new CourseDomainObject(
				$record['course_image'],
				$record['faculty_dept_name'],
				$record['course_name'],
				$record['instructor_name']
			);
		}



	public function findAll(): bool
	{
		// Execute Courses query
		if(!$this->executeQuery('courses', 'allCourses')) {
			return false;
		}
		// Notify observers
		$this->notify();
		return true;
	}
	
	

   

	private function executeQuery($statement, $key): bool 
	{
		$stmt = $this->getstatement($statement);
		if (!$stmt) {
			return false;
		}
		
		if (!$stmt->execute()) {
			return false;
		}

		while ($record = $stmt->fetch()) {
		
			$this->data[$key][] = $this->createObject($record);
		}
		$stmt->closeCursor();
		
		return true;
	}




}

