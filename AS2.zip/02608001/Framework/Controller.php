<?php
namespace Framework;

use Framework\Model;
use Framework\View;


abstract class Controller
{
	
	
    //display model = database 
	protected $model;
	
	//display data on the view page 
 	protected $view;
	
	
	//protected $context;

    // Private constructor to prevent instantiation from outside
    public function __construct()
    {
        //$this->context = new CommandContext();
		
    }
	
	//set model for controller  
	public function setModel(Model $m) 
	{
		$this->model = $m;
	}
	
	
	// set the View object
	public function setView(View $v) 
	{

		$this->view = $v;
	}
	
	
	
	//call the methods within the controller
    //performs the page’s business logic 	
	//abstract public function run( CommandContext $c) :bool;
    abstract public function run();


}