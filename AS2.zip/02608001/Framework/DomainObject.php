<?php

namespace Framework;


abstract class DomainObject
{
    public function get(mixed $fieldname): mixed
    {
        if (isset($this->$fieldname)) {
            return $this->$fieldname;
        }
        return null;
    }
}