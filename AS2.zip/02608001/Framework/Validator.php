<?php
namespace Framework;

class Validator
{


    private static $instance;
    private $errors = [];

    private function __construct(){}

    public static function getInstance() {
        if(empty(self::$instance)) self::$instance = new Validator();
        return self::$instance;
    }
	


        public function isSignUpValid(array $userData) : bool
	   {
		
		  $validEmail = $this->isEmailValid($userData['email']);
		  $validPassword = $this->isPasswordValid($userData['password']);
		  $rePassword = $this->isrepwdValid($userData['password'], $userData['repassword']);
		  $validName = $this->isnameValid($userData['FullName']);

		  
			if(!$validEmail  || !$validPassword || !$validName || !$rePassword || !$validName)
			{
				$this->errors['SignUp Format'] = 'Invalid Input Format';

				return false;
			}

			return true;

				
		}



	  public function isloginValid(array $userData): bool
	  {
		 
		
		
		  $validEmail = $this->isEmailValid($userData['email']);
		  $validPassword = $this->isPasswordValid($userData['password']);
		  
			if(!$validEmail  ||!$validPassword){
			
			  $this->errors['Login Valid'] = 'Email or Password is Invalid';

				return false;
			}

		  return true;
		  
	  }
	  
  
  
       public function isrepwdValid(string $passwd, string $rePasswd):bool
	   {
		   if ($passwd !== $rePasswd) 
		   {
			
				// Passwords don't match
				$this->errors['repeatPassword'] = 'Retype password does not match password';
				return false;
		   }

		  return true;
	   

	   }





	  public function isEmailValid($email) :bool{
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
			
				$this->errors['Email'] = 'Email Format is Invalid';
				
				return false;
			}
			return true;
		}  

     
		
		public function isPasswordValid(string $passwd) : bool
		{

			$isUpLetter = false;
			$isNumber = false;
			$str = $passwd;
			
			//pattern to test length and alphanumeric
			$Pattern = "(^[A-Za-z0-9]{10,18}$)";
			
			$uppercasePattern = '/[A-Z]/';
			$numberPattern = '/[0-9]/';
			
			
			$uppercase = preg_match($uppercasePattern, $str);
			$number = preg_match($numberPattern, $str);

			//check if pattern entered is correct 
			if (!preg_match($Pattern, $str)){
				
				 $this->errors['Password'] = 'Password must be at least 10 characters and only alphanumeric';

			  return false;
			}
			 
			//check for uppercase letter
			if(!$uppercase){
				$this->errors['Password'] = 'Password must contain at least 1 uppercase letter';

	

			   return false;

			}
			
			if (!$number){
				$this->errors['Password'] = 'Password must contain at least 1 digit';

		
				return false;
			}

			return true;

		}     


		public function isnameValid(string $name) : bool
		{
			
			
			$Pattern = "/^(?=.{2,50}$)[a-zA-Z]+(?:[\s\'-][a-zA-Z]+)*$/";
			   
			//check if pattern entered is correct 
			if (!preg_match($Pattern, $name)){
				$this->errors['Name'] = 'Input for full name is invalid';
			   return false;
			}
			 
		   
			return true;
	
		}     
	
      
	  
	  
		   
	   /** 
		* * attach error message to string
		 */
			public function getErrorMessages()
			{
						
				$errors = $this->errors;
				return $errors;

			}








}