<?php
namespace Framework;

var_dump("CommandCon");

class CommandContext
{
	private array $params = [];
		
	public function __construct()
	{
		$this->params = $_REQUEST;
	}
	
	public function addParam(string $key, $val): void
	{
		$this->params[$key] = $val;
	}
	
	public function get(string $key): string
	{
		return $this->params[$key] ?? "";

		/*
		if (isset($this->params[$key])) 
		{
			return $this->params[$key];
		}
		return "";
		*/
	}
	
	
}