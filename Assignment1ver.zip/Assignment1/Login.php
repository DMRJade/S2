<?php
require 'Config/autoloader.php';


//print_r($_POST);

$controller = new LoginController();
$controller->run();