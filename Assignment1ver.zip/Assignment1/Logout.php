<?php
require 'Config/autoloader.php';

$session = new SessionClass();
$session->remove('user');
$session->destroy();

header('Location:index.php');