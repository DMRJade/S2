<?php

require 'Config/autoloader.php';


$controller = new CoursesController();
$controller->run();