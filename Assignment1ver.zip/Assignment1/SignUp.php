<?php

require 'Config/autoloader.php';


$controller = new SignUpController();
$controller->run();