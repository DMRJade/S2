<?php

require 'Config/autoloader.php';


$controller = new ProfileController();
$controller->run();