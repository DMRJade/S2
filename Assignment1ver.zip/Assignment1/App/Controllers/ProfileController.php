<?php

class ProfileController extends AbstractController
{
    
    

    
    public function run()
    {
		SessionClass::create();
          
		// Initialize session
		$session = new SessionClass();

		// Initialize the view
		$this->setView(new ProfileView);
		$this->view->setTemplate(TPL_DIR . '/Profile.tlp.php');

		// Check if the user has access to the profile page
		if (!$session->accessible('user', 'profile')) 
		{
			// If the user doesn't have access, redirect to the login page
			$this->view->setTemplate(TPL_DIR . '/Login.tlp.php');
			$this->view->display();
			exit;
		}

		// Display the view
		$this->view->display();

		}




  

}