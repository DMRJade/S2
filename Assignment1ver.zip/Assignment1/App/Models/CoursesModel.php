<?php
class CoursesModel extends Model
{
    private $Data = [];


    public function getAll() : array
    {
        
        $CoursesArr = [];
       
        
       $coursesQuery = "SELECT courses.course_image,faculty_department.faculty_dept_name, courses.course_name, instructors.instructor_name  
                        FROM courses
                        JOIN instructors ON courses.course_id=instructors.instructor_id 
                        JOIN faculty_dept_courses ON courses.course_id = faculty_dept_courses.course_id
                        JOIN faculty_department ON faculty_department.faculty_dept_id = faculty_dept_courses.faculty_dept_id
                        ORDER BY faculty_department.faculty_dept_name ASC, courses.course_name ASC";


        
        
       $coursesResult = $this->db->query($coursesQuery);
       
        
       while ($row = $coursesResult->fetch_assoc()) 
       {
            $CoursesArr[] = $row;
        }
        
        
       
       
        $this->db->close();
			
        $this->Data = array(
            'Courses' => $CoursesArr
           
        );


        foreach ($this->observers as $observer) {
            $this->notify($observer);
            
        }

         return $this->Data;
    }


    public function getData()
    {
        return $this->Data;
    }




    public function getRecord(string $id) : array
    {

        return [];
    }




   





}

