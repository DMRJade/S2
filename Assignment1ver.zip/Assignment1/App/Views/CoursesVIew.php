<?php


class CoursesView extends View
{

    public function update(Observable $observable)
    {
        $data = $observable->getData(); 

        //print_r(count($data));
        //exit;
     

        foreach ($data as $key => $value) 
        {
                   
            $this->addVar($key, $value);
        
        }
        $this->display();

    }












}