<?php


class LoginVIew extends View
{
    public function update(Observable $observable)
    {
        $data = $observable->getData();

        $session = new SessionClass();
		$session->add(user,  $data['LoginUser'])
		
		


         // var_dump($data);
          //exit;


        if (!empty($data)) 
        {
			   
            if ($data['LoginStatus'] == true)
            {
               var_dump($data['message']);
			   $data['LoginUser']
            }

            
			if ($data['LoginStatus'] === false)
            {
                //$this->addVar('error', $data['message'] );
				
				var_dump("false if statement");
           
            }

        }
		

    
    }












}