<?php

class SignUpView extends View
{

    public function update(Observable $observable)
    {
        $data = $observable->getData();
		
			
		 if (!empty($data)) 
		 {
			 
			if ($data['SignupStatus'] === true)
            {
				//var_dump($data['message'] );
                $this->setTemplate( TPL_DIR . '/login.tlp.php');
                $this->addVar('success', $data['message'] );
				$this->display();
           
            }
			
			elseif ($data['SignupStatus'] === false)
            {
				
                //var_dump("SignupStatus error");
				//var_dump($data['message']);
				
                $this->setTemplate( TPL_DIR . '/signup.tlp.php');
				$this->addVar('SignupMessage', $data['message'] );
				$this->display();
		    }
			 
		 }
		 
		 
		
		
      /*
        if (!empty($data)) 
        {
           if ($data['SignupStatus'] == false)
            {
				
                var_dump($data['message']);
				
                //$this->setTemplate( TPL_DIR . '/signup.tlp.php');
				$this->addVar('errors', $data['message'] );
				$this->display();
				exit;
           
            }

     	  if ($data['SignupStatus'] == true)
            {
                $this->setTemplate( TPL_DIR . '/login.tlp.php');
                $this->addVar('SuccessMessage', $data['message'] );
				$this->display();
           
            }

           

        } */
    }

     
 








}