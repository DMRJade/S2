<?php


class ProfileView extends View
{

    public function update(Observable $observable)
    {
       

    }












}