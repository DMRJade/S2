<?php


class LoginVIew extends View
{
    public function update(Observable $observable)
    {
        $data = $observable->getData();

       	
        if (!empty($data)) 
        {
			   
            if ($data['LoginStatus'] == true)
            {
			   $user = 	$data['LoginUser'];
			   
			   SessionClass::create();
			  		                
			   $session = new SessionClass();
			
			   $session->add('user', $user);
			   
			    $this->addVar('log', true );
			   
			   $this->setTemplate(TPL_DIR . '/Profile.tlp.php');
			   $this->display();
			  
            }
            else if ($data['LoginStatus'] === false)
            {
                //$this->addVar('error', $data['message'] );
				
			     $this->addVar('success', $data['message'] );
				$this->setTemplate(TPL_DIR . '/Login.tlp.php');
				$this->display();
           
            }

        }
		

    
    }









}