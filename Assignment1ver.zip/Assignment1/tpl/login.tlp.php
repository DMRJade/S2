<!DOCTYPE html>
<html lang="en-GB">
	<head>
		<title>Login|Quwius</title>
		<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen">
		<meta charset="utf-8">
	</head>
	<body>
		<nav>
			<a href="#"><img src="images/logo.png" alt="UWI online"></a>
			<ul>
			  <li><a href="Index.php">Index</a></li>
			  <li><a href="Courses.php">Courses</a></li>
			  <li><a href="Profile.php">Profile</a></li>
			  <li><a href="">About Us</a></li>
             <li><?php if(!isset($user)) echo '<a href="login.php">Login</a>'; else echo '<a href="logout.php">Logout</a>';?></li>
			 <li><a href="SignUp.php">Sign Up</a></li>
			</ul>
		</nav>
		<main>
		   <div class="login-box">
			<div class="login-box-body">
			<div>
			<p style="color: blue; font-weight: bold;"><?php if (isset($success)) echo $success   ?></p>
			<p class="login-box-msg">Be Curious - Sign In</p>
				<form action="Login.php" method="post">
			  <div class="form-group has-feedback">
				<input type="text" class="form-control" name="email" placeholder="Email"/>
			  </div>
			  <div class="form-group has-feedback">
				<input type="password" class="form-control" name="password" placeholder="Password"/>
			  </div>
			  <div class="row">
				<div class="col-xs-8">    
				  <div class="checkbox icheck">
					<label>
					  <input type="checkbox"> Remember Me
					</label>
				  </div>                        
				</div><!-- /.col -->
				<div class="col-xs-4">
					<div>
					<?php
                                if (!empty($errors)) : ?>
                                <ul>
                                    <?php 
                                        foreach ($errors as $field=>$msg): ?>
                                        <li style="color: red; font-weight: bold;"><?php echo $field . ':'.$msg ?></li>
                                    <?php 
                                        endforeach; ?>
                                </ul>
                                    <?php 
                                        endif; ?>
                                        </div>




	


					    <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
				</div><!-- /.col -->
			  </div>
			</form>
			<br>
			<a href="SignUp.php" class="text-center">Sign Up</a>
       </div><!-- /.login-box-body -->
	  </div>
	

			<footer>
				<nav>
					<ul>
						<li>&copy;2015 Quwius Inc.</li>
						<li><a href="#">Company</a></li>
						<li><a href="#">Connect</a></li>
						<li><a href="#">Terms &amp; Conditions</a></li>
					</ul>
				</nav>
			</footer>
		</main>
	</body>
</html>