<?php

class SessionClass
{
    private $allowedPages = [
        'profile',
        'courses'
        // Add more pages as needed
    ];

	public static function create()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    public function add($name, $value)
    {
        // Validate name if needed
        $_SESSION[$name] = $value;
    }
    
    public function isLoggedIn($name): bool
    {
		return isset($_SESSION[$name]);
	}

   public function accessible($user, $page): bool
	{
		// Check if the user is logged in
		if (!$this->isLoggedIn($user)) 
		{
			return false;
		}
		
		// Check if the page is in the list of allowed pages
		return in_array($page, $this->allowedPages);
	}

	
	    public function remove($name) 
    {
        if (isset($_SESSION[$name])) {
            unset($_SESSION[$name]);
            return true;
        } 
        return false; // Variable doesn't exist in session
    }
    
    public static function destroy()
    {
        if (session_status() == PHP_SESSION_ACTIVE) {
            // Unset all of the session variables
            $_SESSION = [];
    
            // Delete the session cookie
            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
    
                setcookie(
                    session_name(),
                    '',
                    time() - 42000,
                    $params['path'],
                    $params['domain'],
                    $params['secure'],
                    $params['httponly']
                );
            }
    
            // Finally destroy the session
            session_destroy();
        }
    }
}
