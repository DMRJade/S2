<?php


abstract class Model implements Observable
{
   
    protected $observers = [];
    protected $db;

    public function __construct()
    {
        // Connect to the database
        $this->db = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME );
        if ($this->db->connect_error)
        {
            die('Connection failed: ' . $this->db->connect_error);
        }
    }

  
    public function attach(Observer $observer) 
    {
        $this->observers[] = $observer;
    }

    public function detached(Observer $observer) 
    {
        $key = array_search($observer,$this->observers, true);
        if(false !== $key) 
        {
            unset($this->observers[$key]);
        }
    }

    public function notify(observer $observer)    
    {
        foreach ($this->observers as $observer) 
        {
            $observer->update($this);
        }
    }
	
	
   abstract public function getAll() : array;
   abstract public function getRecord(string $id) : array;





}